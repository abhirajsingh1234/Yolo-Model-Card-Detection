# Sumit_ka_Kaam > version_1
https://universe.roboflow.com/sumitkakaam/sumit_ka_kaam-ljyas

Provided by a Roboflow user
License: CC BY 4.0

